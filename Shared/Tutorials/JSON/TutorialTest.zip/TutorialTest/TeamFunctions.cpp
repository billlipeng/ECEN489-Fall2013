#include "TeamFunctions.h"

void OutputJsonToFile(Document& jsonObject, string fileName)
{
	StringBuffer buffer;
	Writer<StringBuffer> writer(buffer);
	jsonObject.Accept(writer);

	ofstream outputFile;
	outputFile.open(fileName);
	outputFile<<buffer.GetString();
}

void AddArrayToJson(Document& jsonObject, string arrayName, vector<string> values)
{
	Document::AllocatorType& allocator = jsonObject.GetAllocator();

	Value array(kArrayType);
	for(int i = 0; i < values.size(); i++)
	{
		char* value = new char[values[i].size() + 1];
		strcpy(value, values[i].c_str());
		array.PushBack( value, allocator);
	}

	char* name = new char[arrayName.size() + 1];
	strcpy(name, arrayName.c_str());
	jsonObject.AddMember(name, array, allocator);
}

void AddObjectToJson(Document& jsonObject, string objectName, vector<string> names, vector<string> values)
{
	Document::AllocatorType& allocator = jsonObject.GetAllocator();

	Value object(kObjectType);
	for(int i = 0; i < names.size(); i++)
	{
		char* name = new char[names[i].size() + 1];
		strcpy(name, names[i].c_str());
		char* value = new char[values[i].size() + 1];
		strcpy(value, values[i].c_str());
		object.AddMember(name, value, allocator);
	}

	char* name = new char[objectName.size() + 1];
	strcpy(name, objectName.c_str());
	jsonObject.AddMember(name, object, allocator);
}