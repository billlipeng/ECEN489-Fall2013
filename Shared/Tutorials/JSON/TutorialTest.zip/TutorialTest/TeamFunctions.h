#include "rapidjson/document.h"
#include "rapidjson/filestream.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"
#include <iostream>
#include <typeinfo>
#include <stdio.h>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
using namespace rapidjson;

void OutputJsonToFile(Document& jsonObject, string fileName);
void AddArrayToJson(Document& jsonObject, string arrayName, vector<string> values);
void AddObjectToJson(Document& jsonObject,string objectName, vector<string> names, vector<string> values);