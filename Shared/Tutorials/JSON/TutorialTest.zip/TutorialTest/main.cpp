#include "TeamFunctions.h"

using namespace std;
using namespace rapidjson;

struct Latitude{
	int degrees;
	int minutes;
	int seconds;
};

int main()
{
	ifstream ifs("jsonFile.txt");
	string s;
	s.assign(istreambuf_iterator<char>(ifs),istreambuf_iterator<char>());
	rapidjson::Document jsonObject;
	jsonObject.Parse<0>(s.c_str());

	/*
	//test value
	bool isString = jsonObject["release date"].IsString();
	cout<<isString<<endl;
	
	//STUDENTS: determine if the json object has a field
	//HINT: use the FindMember function from the rapidjson library

	//get a value form the json file
	cout<<jsonObject["arduino ID"].GetString()<<endl;

	//retrieve an array from json
	Value& array = jsonObject["time stamp"];
	SizeType i = 0;
	cout<<array[i].GetString()<<endl<<array[i+1].GetString()<<endl;

	//mutate objects within the json file
	jsonObject["arduino ID"] = 262;
	jsonObject["geo location"]["latitude"]["degrees"] = "sure";

	//STUDENTS: modify a json array
	//HINT: It is not as easy as replacement, will require creating a new 
	//array and setting the "name" equal to the new array

	//reading objects out of json
	Value& latitudeFromJson = jsonObject["geo location"]["latitude"];
	Latitude latitude;
	latitude.degrees = latitudeFromJson["degrees"].GetInt();
	latitude.minutes = latitudeFromJson["minutes"].GetInt();
	latitude.seconds = latitudeFromJson["seconds"].GetInt();

	cout<<latitude.degrees<<" "<<latitude.minutes<<" "<<latitude.seconds<<endl;

	//creating a new object
	vector<string> names;
	names.push_back("Yes");
	names.push_back("No");
	vector<string> values;
	values.push_back("Maybe");
	values.push_back("I suppose");

	//creatine a new array
	vector<string> arrayValues;
	arrayValues.push_back("For the Win!");
	arrayValues.push_back("Just Awesome");
	arrayValues.push_back("Never!!!");

	AddArrayToJson(jsonObject, "New Array", arrayValues);
	AddObjectToJson(jsonObject, "New Object", names, values);
	
	OutputJsonToFile(jsonObject, "output.txt");
	*/
	char x;
	cin>>x;
}